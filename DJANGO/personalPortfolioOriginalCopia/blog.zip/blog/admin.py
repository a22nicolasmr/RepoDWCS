from django.contrib import admin
from .models import Blogs


admin.site.register(Blogs)
