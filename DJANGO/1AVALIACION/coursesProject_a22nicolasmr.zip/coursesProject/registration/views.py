from django.shortcuts import render
from .models import Registration

# Create your views here.
def home(request):
    registrations=Registration.objects.order_by('-date')
    return render(request, 'registrationHtmls/registration.html',{'registrations':registrations})