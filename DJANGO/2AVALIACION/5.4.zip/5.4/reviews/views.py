from django.shortcuts import render
from django.http import HttpResponseRedirect
from .forms import StudentForm
from .models import Student
from django.views.generic.base import TemplateView
from django.views.generic import ListView, DetailView
from django.views.generic import FormView
from django.views.generic.edit import CreateView,UpdateView,DeleteView
from django.urls import reverse_lazy

    
    
class ReviewStudent(CreateView):
    model=Student
    form_class=StudentForm
    template_name="reviews/student.html"
    success_url="thank_you"
    
class ThankYouStudent(TemplateView):
    template_name="reviews/thank_you.html"
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["message"] = "This works!" 
        return context
    
class ReviewsListStudent(ListView):
    template_name="reviews/student_list.html"
    model=Student
    context_object_name="students"
    
class SingleReviewStudent(DetailView):
    template_name="reviews/single_student.html"
    model=Student
    context_object_name="student"
    
class UpdateStudent(UpdateView):
    model = Student
    form_class = StudentForm
    template_name = "reviews/update_student.html" 
    success_url = reverse_lazy('thank_you')  
    
class DeleteStudent(DeleteView):
    model = Student
    template_name = "reviews/delete_student.html"  
    success_url = reverse_lazy('thank_you')  

