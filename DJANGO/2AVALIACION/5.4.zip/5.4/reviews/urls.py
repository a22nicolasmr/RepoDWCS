from django.urls import path

from . import views

urlpatterns = [
    path("", views.ReviewStudent.as_view(), name="home"),
    path("thank_you/", views.ThankYouStudent.as_view(),name='thank_you'),
    path("students/", views.ReviewsListStudent.as_view(),name='students'),
    path("students/<int:pk>", views.SingleReviewStudent.as_view(),name='students'),
    path('student/update/<int:pk>/', views.UpdateStudent.as_view(), name='update_student'),
    path('student/delete/<int:pk>/', views.DeleteStudent.as_view(), name='delete_student'),
]