from django.contrib import admin
from .models import Reseñas
# Register your models here.

admin.site.register(Reseñas)